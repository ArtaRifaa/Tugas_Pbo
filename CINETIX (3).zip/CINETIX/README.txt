Mata kuliah: Pemrograman Berorientasi Objek
Dosen Pengampu: Herika Hayurani

Kelompok [CodeCine]:
[Muhammad Daffa Indra Pradana], [A], [1402024032]
[Arta Ma’ruf Rifaa ‘Ulwan], [A], [1402024011]
[Andhika Bayu Nugraha ], [B], [(1402024009]

Berkas ini menjelaskan kelengkapan berkas proyek akhir kami yang berjudul [CineTix]. 
Berkas terdiri dari:
File database sql dengan nama database: [cinetix]
Source code project [NetBeans]
Tautan Repository GitHub: [https://github.com/ArtaRifaa/Tugas_Pbo]